$(document).ready(function(){

// $('#simple_arc').circleType({radius:135});

// $('h1').circleType();

// $('#circle1').CircleType();

  $('#circle1').circleType();


// new CircleType(document.getElementById('#circle1'));

});